package ir.noshirvani413.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int BLUE = Color.rgb(6,74,135);
    final int LIGHT = Color.rgb(241,247,252);
    final int TEXT = Color.rgb(22,50,74);
    LinearLayout root, content, bottom;
    ImageView logo;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BLUE);
        showHome();
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setTypeface(null, bold ? 1 : 0);
        t.setPadding(14, 10, 14, 10);
        return t;
    }

    GradientDrawable bg(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(r); return g;
    }

    TextView card(String icon, String title, String sub) {
        TextView t = tv(icon + "\n" + title + (sub.isEmpty() ? "" : "\n" + sub), 14, TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(bg(Color.WHITE, 28));
        t.setPadding(8, 14, 8, 14);
        return t;
    }

    void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LIGHT); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(12, 6, 12, 6); bar.setBackgroundColor(BLUE);
        TextView back = tv("‹", 32, Color.WHITE, false);
        back.setGravity(Gravity.CENTER); bar.addView(back, new LinearLayout.LayoutParams(52,64));
        TextView h = tv(title, 19, Color.WHITE, true); h.setGravity(Gravity.CENTER);
        bar.addView(h, new LinearLayout.LayoutParams(0,64,1));
        root.addView(bar);
        back.setOnClickListener(v -> showHome());

        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(14, 14, 14, 14);
        ScrollView sc = new ScrollView(this); sc.addView(content);
        root.addView(sc, new LinearLayout.LayoutParams(-1,0,1));

        bottom = new LinearLayout(this); bottom.setGravity(Gravity.CENTER);
        bottom.setBackgroundColor(Color.WHITE);
        String[] labels={"خانه","امکانات","اخبار","آموزش","پروفایل"};
        String[] icons={"⌂","▦","◉","▤","●"};
        for(int i=0;i<labels.length;i++){
            TextView n=tv(icons[i]+"\n"+labels[i],11,TEXT,true); n.setGravity(Gravity.CENTER);
            final int k=i; n.setOnClickListener(v -> { if(k==0) showHome(); else if(k==2) showNews(); else if(k==3) showEducation(); else if(k==1) showFeatures(); else showProfile();});
            bottom.addView(n,new LinearLayout.LayoutParams(0,66,1));
        }
        root.addView(bottom);
        setContentView(root);
    }

    void showHome() {
        base("هنرستان فنی‌وحرفه‌ای نوشیروانی ۴۱۳ بابل");

        ImageView hero=new ImageView(this); hero.setImageResource(ir.noshirvani413.app.R.drawable.school_gate);
        hero.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable hb=bg(BLUE,30); hero.setBackground(hb); hero.setClipToOutline(true);
        content.addView(hero,new LinearLayout.LayoutParams(-1,230));

        logo=new ImageView(this); logo.setImageResource(R.drawable.school_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        content.addView(logo,new LinearLayout.LayoutParams(-1,115));

        TextView welcome=tv("هنرستان فنی‌وحرفه‌ای زنده‌یاد نوشیروانی ۴۱۳ بابل\nدانش • مهارت • آینده بهتر",19,TEXT,true);
        welcome.setGravity(Gravity.CENTER); content.addView(welcome);

        GridLayout grid=new GridLayout(this); grid.setColumnCount(3); grid.setUseDefaultMargins(true);
        String[][] items={{"📚","کتب درسی",""},{"📅","برنامه هفتگی",""},{"📝","امتحانات",""},{"👨‍🏫","همکاران",""},{"🏆","افتخارات",""},{"🛠","پروژه‌ها",""},{"🖼","گالری تصاویر",""},{"📢","اطلاعیه‌ها",""},{"☎","تماس با ما",""}};
        for(String[] it:items){
            TextView c=card(it[0],it[1],"");
            grid.addView(c,new GridLayout.LayoutParams());
            c.setOnClickListener(v -> {
                String x=((TextView)v).getText().toString();
                if(x.contains("کتب")) showBooks(); else if(x.contains("برنامه هفتگی")) showSchedule();
                else if(x.contains("امتحانات")) showExams(); else if(x.contains("همکاران")) showStaff();
                else if(x.contains("افتخارات")) showAwards(); else if(x.contains("پروژه")) showProjects();
                else if(x.contains("گالری")) showGallery(); else if(x.contains("اطلاعیه")) showNews(); else showContact();
            });
        }
        content.addView(grid);

        TextView latest=tv("آخرین خبر\nبرگزاری رویدادها و فعالیت‌های آموزشی و مهارتی هنرستان",15,TEXT,true);
        latest.setBackground(bg(Color.WHITE,26)); content.addView(latest,new LinearLayout.LayoutParams(-1,90));
    }

    void listScreen(String title, String[] rows) {
        base(title);
        for(String s:rows){
            TextView r=tv("›  "+s,16,TEXT,true); r.setBackground(bg(Color.WHITE,24));
            content.addView(r,new LinearLayout.LayoutParams(-1,76));
            Space sp=new Space(this); content.addView(sp,new LinearLayout.LayoutParams(1,8));
        }
    }
    void showNews(){ listScreen("اخبار و اطلاعیه‌ها",new String[]{"برگزاری مسابقات مهارتی در هنرستان","آغاز سال تحصیلی جدید","اطلاعیه ثبت‌نام و برنامه‌های آموزشی","تجلیل از هنرجویان برتر","جلسات و رویدادهای هنرستان"}); }
    void showEducation(){ listScreen("آموزش",new String[]{"کتب درسی","برنامه هفتگی","برنامه امتحانات","رشته الکترونیک","رشته الکتروتکنیک"}); }
    void showBooks(){ listScreen("کتب درسی",new String[]{"طراحی و ساخت مدارهای چاپی — کد ۲۱۰۲۷۸","کتب پایه دهم الکترونیک","کتب پایه یازدهم الکترونیک","کتب پایه دوازدهم الکتروتکنیک"}); }
    void showSchedule(){ listScreen("برنامه هفتگی",new String[]{"شنبه — ریاضی، برنامه‌نویسی، سیستم عامل","یکشنبه — کارگاه و دروس تخصصی","دوشنبه — نقشه‌کشی و الکترونیک","سه‌شنبه — دروس عمومی و تخصصی","چهارشنبه — نقشه‌کشی","پنجشنبه — کارگاه"}); }
    void showExams(){ listScreen("برنامه امتحانات",new String[]{"ریاضی — پایه دهم","فیزیک — پایه دهم","کارگاه عملی — پایه یازدهم","زبان انگلیسی — پایه یازدهم"}); }
    void showStaff(){ listScreen("معرفی همکاران",new String[]{"کادر اداری هنرستان","هنرآموزان الکتروتکنیک","هنرآموزان الکترونیک","معاونان و عوامل اجرایی"}); }
    void showAwards(){ listScreen("افتخارات",new String[]{"موفقیت هنرجویان در مسابقات مهارتی","هفتمین دوره المپیاد رویداد کارآفرینی شتاب","دستاوردهای علمی و فنی هنرستان","هنرجویان برتر و افتخارآفرین"}); }
    void showProjects(){ listScreen("پروژه‌ها و دست‌ساخته‌ها",new String[]{"پروژه‌های الکترونیک","پروژه‌های الکتروتکنیک","هوشمندسازی و رباتیک","نمایشگاه دست‌ساخته‌ها"}); }
    void showGallery(){ listScreen("گالری تصاویر",new String[]{"تصاویر هنرستان","کارگاه‌ها و آزمایشگاه‌ها","مراسم و رویدادها","مسابقات و نمایشگاه‌ها"}); }
    void showFeatures(){ listScreen("امکانات",new String[]{"کتابخانه هوشمند دیجیتال","تقویم اجرایی و آیین‌نامه‌ها","جلسات و آموزش","بازدید مجازی","پیش‌ثبت‌نام غیرحضوری"}); }
    void showContact(){ listScreen("تماس با هنرستان",new String[]{"هنرستان فنی‌وحرفه‌ای نوشیروانی ۴۱۳ بابل","وب‌سایت: noshirvani413.ir","ارتباط با هنرستان","مسیریابی"}); }
    void showProfile(){ listScreen("پروفایل و تنظیمات",new String[]{"تنظیمات برنامه","درباره هنرستان","ارتباط با ما","راهنما","نسخه برنامه ۱.۰.۰"}); }
}
