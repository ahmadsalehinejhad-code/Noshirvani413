# Noshirvani 413 — Android Release-Ready Project

این نسخه برای مرحله Build خروجی APK آماده شده است.

## مشخصات
- Application ID: `ir.noshirvani413.app`
- Version: `1.0.0`
- Min SDK: 23 (Android 6.0+)
- Target SDK: 35
- فارسی و RTL
- عکس واقعی ورودی هنرستان و لوگوی اصلی
- ساختار Release و Debug
- Gradle Wrapper 8.9
- مجوز Internet برای اتصال مرحله بعد به سایت هنرستان

## ساخت APK در Android Studio
1. Android Studio را نصب کنید.
2. فایل ZIP را Extract کنید.
3. در Android Studio گزینه **Open** را بزنید و پوشه `Noshirvani413_Android_ReleaseReady_v2` را انتخاب کنید.
4. صبر کنید Gradle Sync کامل شود.
5. برای تست: `Build > Build APK(s)`
6. برای نسخه Release: `Build > Generate Signed Bundle / APK` و سپس APK را انتخاب کنید.
7. کلید امضای Release را با نام و رمز دلخواه خودتان بسازید و نزد خودتان نگه دارید.

Android برای توزیع APK به امضای دیجیتال نیاز دارد؛ کلید خصوصی را نباید داخل پروژه عمومی قرار داد.

## Build خط فرمان
در Windows:
`gradlew.bat assembleDebug`

برای Release:
`gradlew.bat assembleRelease`

در Linux/macOS:
`./gradlew assembleDebug`
`./gradlew assembleRelease`

## خروجی
Debug:
`app/build/outputs/apk/debug/`

Release:
`app/build/outputs/apk/release/`

## نکته
این محیط فعلی Android SDK ندارد، بنابراین APK نهایی در اینجا Build نشده است. پروژه و Wrapper برای Build در Android Studio آماده شده‌اند.
